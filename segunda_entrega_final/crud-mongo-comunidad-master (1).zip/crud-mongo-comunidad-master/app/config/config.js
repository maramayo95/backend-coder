
var admin = require("firebase-admin");
var serviceAccount = require("./ecommerce-dde6f-firebase-adminsdk-yvkl6-7674b98f02.json");
module.exports = {admin, serviceAccount}